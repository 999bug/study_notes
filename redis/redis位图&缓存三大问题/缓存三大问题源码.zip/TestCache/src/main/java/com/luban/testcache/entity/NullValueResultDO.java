package com.luban.testcache.entity;

import lombok.*;

@Getter
@Setter
@ToString
public class NullValueResultDO{
//    private String name;
}