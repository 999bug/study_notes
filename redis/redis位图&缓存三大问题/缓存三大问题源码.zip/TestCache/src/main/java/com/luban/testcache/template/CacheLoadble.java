package com.luban.testcache.template;

public interface CacheLoadble<T> {
    T load();
}
